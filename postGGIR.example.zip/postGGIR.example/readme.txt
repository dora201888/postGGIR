

GGIR was run on GGIR 2.4.0 under R 4.0.5
postGGIR 2.4.0.1 was run under R 4.1.0


The raw accelerometer data was removed from example/GGIR/binfile due to size limitation of github.